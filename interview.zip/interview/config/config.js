data = {
    store: {
        JWT_KEY: "secret"
    }
}
module.exports = data;